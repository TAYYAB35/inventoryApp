import { useState } from 'react';
import { Outlet, Navigate } from 'react-router-dom';


const PrivateRouter = () => {
  const [userInfo, SetUserInfo] = useState(false)

  return (
    <div>
      {userInfo ? <Outlet /> :
        <Navigate to="/login" replace />}
    </div>
  )
}

export default PrivateRouter