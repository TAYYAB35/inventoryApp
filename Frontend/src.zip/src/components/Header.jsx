import { Layout } from 'antd';

const Header = () => {
    const { Header } = Layout;
    return (
        <>
            <Header className='!bg-white' >

            </Header>
        </>
    )
}

export default Header