import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import { LoginScreen} from './screen/index.js';

import App from './App.tsx';
import PrivateRouter from './components/PrivateRouter.jsx';



import './index.css'
import AdminRouter from './components/AdminRouter.jsx';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<App />} >
      <Route path='/login' element={<LoginScreen />} />

      <Route path='' element={<PrivateRouter />}>
      </Route>

      <Route path='' element={<AdminRouter />}>
      </Route>

    </Route>
  )
)

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
